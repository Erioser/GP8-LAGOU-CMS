
console.log = () => {}
console.error = () => {}
console.info = () => {}

