
import '../stylesheets/admin.scss';

import admin_controller from './controllers/admin'


admin_controller.init()