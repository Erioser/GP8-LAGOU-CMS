// 做一些全局的配置
module.exports = {

    version: 'v1'

}