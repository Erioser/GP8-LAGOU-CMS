var express = require('express');
var router = express.Router();

/* GET home page. */
// router.get('/', function(req, res, next) {
//   // 渲染模板引擎代码
//   // 从引擎目录取出index，进行渲染， 因为引擎为ejs引擎，所以这里渲染的是ejs的模板 （index.ejs）
//   // res.render('index', { title: 'Express', str: '<h1>Hello World</h1>' });
// });

module.exports = router;
